using DDD.CarRental.Core.DomainModelLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DDD.CarRental.Core.InfrastructureLayer.EF.EntityConfigurations {
	public class CarConfiguration : IEntityTypeConfiguration<Car> {
		public void Configure(EntityTypeBuilder<Car> CarConfiguration) {
			// ustawienia klucza g��wnego
			CarConfiguration.HasKey(c => c.Id);
			// klucz tabeli nie b�dzie generowany przez EF
			CarConfiguration.Property(c => c.Id).ValueGeneratedNever();
			// wykluczenie DomainsEvents z modelu relacyjnego 
			CarConfiguration.Ignore(c => c.DomainEvents);
			// konfiguracja pozostalych element�w
			CarConfiguration.Property(c => c.RegistrationNumber).IsRequired().HasMaXLength(20);
			CarConfiguration.Property(c => c.DailyRate).IsRequired().HasColumnType("decimal(18,2)");
			CarConfiguration.Property(c => c.Status).IsRequired().HasConversion<string>();
			// konfiguracja warto�ci element�w
			CarConfiguration.OwnsOne(c => c.CurrentPosition, position => {
				position.Property(p => p.X).HasColumnName("CurrentPosition_X").IsRequired();
				position.Property(p = > p.Y).HasColumnName("CurrentPosition_Y").IsRequired();
				position.Property(p = > p.Unit).HasColumnName("CurrentPosition_Unit").IsRequired().HasMaxLength(20);
			});

			CarConfiguration.OwnsOne(c => c.TotalDistance, distance => {
				distance.Property(d => d.Value).HasColumnName("TotalDistance_Value").IsRequired();
				distance.Property(d = > d.Unit).HasColumnName("TotalDistance_Unit").IsRequired().HasMaxLength(20);
			});

			CarConfiguration.OwnsOne(c => c.CurrentDistance, distance => {
				distance.Property(d => d.Value).HasColumnName("CurrentDistance_Value").IsRequired();
				distance.Property(d = > d.Unit).HasColumnName("CurrentDistance_Unit").IsRequired().HasMaxLength(20);
			});
		}
	}
}
