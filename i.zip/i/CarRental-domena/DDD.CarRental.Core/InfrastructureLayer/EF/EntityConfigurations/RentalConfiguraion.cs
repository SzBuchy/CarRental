using DDD.CarRental.Core.DomainModelLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DDD.CarRental.Core.InfrastructureLayer.EF.EntityConfigurations
{
    public class Rental Configuration : IEntityTypeConfiguration<Rental>
    {
        public void Configure(EntityTypeBuilder<Rental> RentalConfiguration)
        {
            // ustawienia klucza g��wnego
            RentalConfiguration.HasKey(r => r.Id);
            // klucz tabeli nie b�dzie generowany przez EF
            RentalConfiguration.Property(r => r.Id).ValueGeneratedNever();
            // wykluczenie DomainsEvents z modelu relacyjnego 
            RentalConfiguration.Ignore(r => r.DomainEvents);
            // konfiguracja pozostalych element�w
            RentalConfiguration.Property(r => r.RStartedAt).IsRequired();
            RentalConfiguration.Property(r => r.FinishedAt);
            RentalConfiguration.Property(r => r.TotalAmount).IsRequired().HasColumnType("decimal(18,2)");
            // konfiguracja warto�ci element�w
            RentalConfiguration.OwnsOne(r => r.Total, money => {
              money.Property(m => m.Amount).HasColumnName("Total_Amount").HasColumnType("decimal(18,2)");
              money.Property(m = > money.Currency).HasColumnName("Total_Currency").IsRequired().HasMaxLength(10);
            });
            RentalConfiguration.OwnsOne(r => r.Renter, renter => {
              renter.Property(rn => rn.DriverId).IsRequired().HasColumnName("Renter_DriverId");
              renter.Property(rn = > rn.LicenceNumber).HasColumnName("Renter_LicenceNumber").IsRequired().HasMaxLength(30);
              renter.Property(rn = > rn.FirstName).HasColumnName("Renter_FirstName").IsRequired().HasMaxLength(30);
              renter.Property(rn = > rn.LastName).HasColumnName("Renter_LastName").IsRequired().HasMaxLength(50);
            });
            RentalConfiguration.OwnsOne(r => r.RentedCar, rentedCar => {
              rentedCar.Property(rc => rc.CarId).IsRequired().HasColumnName("RentedCar_CarId");
              rentedCar.Property(rc = > rc.RegistrationNumber).HasColumnName("RentedCar_RegistrarionNumber").IsRequired().HasMaxLength(20);
              rentedCar.Property(rc = > rc.DailyRate).HasColumnName("RentedCar_DailyRate").IsRequired().HasColumnType("decimal(18,2)");
        });